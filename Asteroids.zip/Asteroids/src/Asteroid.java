import edu.digipen.gameobject.GameObject;
import edu.digipen.gameobject.ObjectManager;
import edu.digipen.level.GameLevel;
import edu.digipen.math.PFRandom;
import edu.digipen.math.Vec2;

/**
 * Created by Anshul Karanam on 7/17/2017.
 * Class for how asteroids interact in the game
 */
public class Asteroid extends GameObject{
    public int size;
    public ArenaLevel level;
    public Asteroid(int size, Vec2 velocity, ArenaLevel level)



    {
        super("asteroid", size, size, "CircleLarge.png");
        this.level = level;
        setCircleCollider(size/2.0f);
        setVelocity(velocity);
        this.size = size;

    }


    @Override public void collisionReaction(GameObject other)
    {
        if(other.getName() == "bullet")
        {
            /*Function that when an asteroid is broken, turns into 4 pieces, then 2 pieces*/
            if(size>=128)
            {
                Vec2 vel1 = new Vec2(PFRandom.randomRange(-120,120), PFRandom.randomRange(-120, 120));
                Asteroid aster1 = new Asteroid(32, vel1, level);
                ObjectManager.addGameObject(aster1);
                aster1.setPosition(getPosition());

                Vec2 vel2 = new Vec2(PFRandom.randomRange(-120,120), PFRandom.randomRange(-120, 120));
                Asteroid aster2 = new Asteroid(32, vel2, level);
                ObjectManager.addGameObject(aster2);
                aster2.setPosition(getPosition());

                Vec2 vel3 = new Vec2(PFRandom.randomRange(-120,120), PFRandom.randomRange(-120, 120));
                Asteroid aster3 = new Asteroid(32, vel3, level);
                ObjectManager.addGameObject(aster3);
                aster3.setPosition(getPosition());

                Vec2 vel4 = new Vec2(PFRandom.randomRange(-120,120), PFRandom.randomRange(-120, 120));
                Asteroid aster4 = new Asteroid(32, vel4, level
                );
                ObjectManager.addGameObject(aster4);
                aster4.setPosition(getPosition());

            }
            else if(size==32)
            {
                Vec2 vel1 = new Vec2(PFRandom.randomRange(-60, 60), PFRandom.randomRange(-60, 60));
                Asteroid aster5 = new Asteroid(16, vel1, level);
                ObjectManager.addGameObject(aster5);
                aster5.setPosition(getPosition());

                Vec2 vel2 = new Vec2(PFRandom.randomRange(-60, 60), PFRandom.randomRange(-60, 60));
                Asteroid aster6 = new Asteroid(16, vel2, level);
                ObjectManager.addGameObject(aster6);
                aster6.setPosition(getPosition());
            }
            level.addToScore(100);
            kill();

        }
    }

    @Override public void update(float dt)
    {
        checkWrap();
    }

    public void checkWrap()
    {
        float halfScreenWidth = edu.digipen.graphics.Graphics.getWindowWidth()/ 2.0f;
        float halfScreenHeight = edu.digipen.graphics.Graphics.getWindowHeight() / 2.0f;
        float offset = size/2.0f;


        if(getPositionX() - offset > halfScreenWidth)
        {
            setPositionX(-halfScreenWidth - offset);
        }
        if(getPositionX() + offset < -halfScreenWidth)
        {
            setPositionX(halfScreenWidth + offset);
        }
        if(getPositionY() - offset > halfScreenHeight)
        {
            setPositionY(-halfScreenHeight - offset);
        }
        if(getPositionY() + offset < -halfScreenHeight)
        {
            setPositionY(halfScreenHeight + offset);
        }


    }

}
