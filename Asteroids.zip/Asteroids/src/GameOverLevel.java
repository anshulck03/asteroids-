import edu.digipen.InputManager;
import edu.digipen.SoundManager;
import edu.digipen.level.GameLevel;
import edu.digipen.level.GameLevelManager;
import edu.digipen.text.FontTypes;
import edu.digipen.text.TextObject;

import java.awt.event.KeyEvent;

/**
 * Created by Anshul Karanam on 7/18/2017.
 * level for the end of the game
 */
public class GameOverLevel extends GameLevel
{
    public int score;

    public GameOverLevel(int score)
    {
        super();
        this.score = score;
    }

    public void create()
    {

        TextObject scoreText = new TextObject("Score Text","Your Final score is " + score + "!" + "\nThanks for playing!" + "\nHit R to replay.", FontTypes.ARIAL_32);

}
    public void initialize()
    {

    }
    public void update(float dt)
    {
        if(InputManager.isTriggered(KeyEvent.VK_R))
        {
            GameLevelManager.goToLevel(new ArenaLevel());
        }

    }
    public void uninitialize()
    {

    }
}
