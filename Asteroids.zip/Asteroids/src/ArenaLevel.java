import edu.digipen.InputManager;
import edu.digipen.SoundManager;
import edu.digipen.gameobject.GameObject;
import edu.digipen.gameobject.ObjectManager;
import edu.digipen.graphics.Graphics;
import edu.digipen.level.GameLevel;
import edu.digipen.level.GameLevelManager;
import edu.digipen.math.PFRandom;
import edu.digipen.math.Vec2;
import edu.digipen.text.FontTypes;
import edu.digipen.text.TextObject;

import java.awt.event.KeyEvent;

/**
 * Created by Anshul Karanam on 7/14/2017.
 * Starting level for the asteroids game
 */
public class ArenaLevel extends GameLevel
{
    public float timer = 5.0f;
    public float coolDown = 5.0f;
    public TextObject text;
    public int score = 0;
    public int lives;
    public TextObject livesText;

    public void addToScore(int addition)
    {

        score += addition;
        text.setText("Score: " + score);
    }

    public void updateLives()
    {

        livesText.setText("Lives: " + lives);
    }
    @Override public void create()
    {
        System.out.print(lives);
        lives = 3;
        float offset = 64;
        float halfScreenWidth = Graphics.getWindowWidth() / 2.0f;
        float halfScreenHeight = Graphics.getWindowHeight() / 2.0f;
        text = new TextObject("ScoreText", "Score: " + score, FontTypes.ARIAL_16);
        text.setColor(0.5f,0.5f, 0.5f, 1f);
       text.setZOrder(300);
       text.setScale(2, 2);
       text.setPosition(-350, 220);

        livesText = new TextObject("LivesText", "Lives: " + lives, FontTypes.ARIAL_16);
        livesText.setColor(0.5f,0.5f, 0.5f, 1f);
        livesText.setZOrder(300);
        livesText.setScale(2, 2);
        livesText.setPosition(-350, 250);

        SoundManager.addBackgroundSound("BGMusic", "LevelMusic.wav", true);
        SoundManager.addSoundEffect("PewPew", "Laser_Shoot8.wav");
        SoundManager.addSoundEffect("Rip", "Explosion3.wav");
        updateLives();
    }
    @Override public void initialize()
    {
        SoundManager.playBackgroundSound("BGMusic");
        PlayerShip player = new PlayerShip(this);
        ObjectManager.addGameObject(player);



    }
    @Override public void update(float dt)
    {

        if (timer >= coolDown)
        {
            spawnAsteroid();

            timer = 0;
        }
        timer += dt;

        if(InputManager.isTriggered(KeyEvent.VK_R))
        {
            GameLevelManager.restartLevel();

        }
    }
    public void uninitialize()
    {
      ObjectManager.removeAllObjects();
    }
    public void spawnAsteroid()
    {
        float halfScreenWidth = edu.digipen.graphics.Graphics.getWindowWidth()/ 2.0f;
        float halfScreenHeight = edu.digipen.graphics.Graphics.getWindowHeight() / 2.0f;
        float offset = 64;


        Vec2 vel = new Vec2(PFRandom.randomRange(-70,70),
                PFRandom.randomRange(-70,70));
        Asteroid asteroid = new Asteroid(128, vel, this);
        ObjectManager.addGameObject(asteroid);
        int sidetospawn = PFRandom.randomRange(1,4);
        if(sidetospawn==1)
        {
            asteroid.setPositionX(halfScreenWidth+offset);
            asteroid.setPositionY(PFRandom.randomRange(-halfScreenHeight, halfScreenHeight));
        }
        else if(sidetospawn == 2)
        {
            asteroid.setPositionX(PFRandom.randomRange(-halfScreenWidth, halfScreenWidth));
            asteroid.setPositionY(halfScreenHeight+offset);

        }
        else if(sidetospawn == 3)
        {

            asteroid.setPositionX(-halfScreenWidth-offset);
            asteroid.setPositionY(PFRandom.randomRange(-halfScreenHeight, halfScreenHeight));
        }
        else
        {
            asteroid.setPositionX(PFRandom.randomRange(-halfScreenWidth, halfScreenWidth));
            asteroid.setPositionY(-halfScreenHeight-offset);

        }



    }



}
