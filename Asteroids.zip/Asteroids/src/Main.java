import edu.digipen.Game;
import edu.digipen.level.EmptyLevel;

/**
 * Created by Anshul Karanam on 7/14/2017.
 * Asteroids, top down game project
 */
/*Game Engine*/
public class Main {
    public static void main(String[] args)
    {
        Game.initialize(1080,1200,70, new MainMenu());

        while(!Game.getQuit())
        {
            Game.update();
        }
        Game.destroy();
    }
}

