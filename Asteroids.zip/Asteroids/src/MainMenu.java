import edu.digipen.InputManager;
import edu.digipen.level.GameLevel;
import edu.digipen.level.GameLevelManager;
import edu.digipen.text.FontTypes;
import edu.digipen.text.TextObject;

import java.awt.event.KeyEvent;

/**
 * Created by Anshul Karanam on 7/18/2017.
 * level for starting the game on
 */
public class MainMenu extends GameLevel
{
    public MainMenu()
    {
        super();
    }
    public void create()
    {
        TextObject menu = new TextObject("Menu", "WASD TO CONTROL SPACESHIP, \n SPACE TO FIRE, & R TO RESTART. \n PRESS SPACE TO START GAME!", FontTypes.ARIAL_32);


    }
    public void initialize()
    {

    }
    public void update(float dt)
    {
        if(InputManager.isTriggered(KeyEvent.VK_SPACE))
        {
            GameLevelManager.goToLevel(new ArenaLevel());
        }
    }
    public void uninitialize()
    {

    }

}
