import edu.digipen.InputManager;
import edu.digipen.SoundManager;
import edu.digipen.gameobject.GameObject;
import edu.digipen.gameobject.ObjectManager;
import edu.digipen.graphics.*;
import edu.digipen.level.GameLevel;
import edu.digipen.level.GameLevelManager;
import edu.digipen.math.Vec2;

import java.awt.*;
import java.awt.Graphics;
import java.awt.event.KeyEvent;

/**
 * Created by Anshul Karanam on 7/17/2017.
 * Class for the player and all the player ship controls
 */

/*Functions for PlayerShip controls, and how it works in the engine*/
public class PlayerShip extends GameObject{
    public Vec2 direction = new Vec2(1, 0);
    public float speed = 1.5f;
    public float timer = 3;
    public float coolDown = 0.5f;
    public ArenaLevel level;




    public PlayerShip(ArenaLevel level)
    {
        super("player", 100, 100, "Ship.png");
        setCircleCollider(40);
        this.level =level;
        setCircleCollider(28);
    }



    /*Controls WASD*/
    @Override public void update(float dt) {
        if (InputManager.isPressed(KeyEvent.VK_W)) {
            addForce(Vec2.scale(direction, speed),0.16f);
        }
        if (InputManager.isPressed(KeyEvent.VK_S)) {
            addForce(Vec2.scale(direction, -speed), 0.16f);
        }
        if (InputManager.isPressed(KeyEvent.VK_A)) {
            setRotation(getRotation() + 1);
            double radians = Math.toRadians(getRotation());
            direction.setX((float) Math.cos(radians));
            direction.setY((float) Math.sin(radians));
        }
        if (InputManager.isPressed(KeyEvent.VK_D)) {
            setRotation(getRotation() - 1);
            double radians = Math.toRadians(getRotation());
            direction.setX((float) Math.cos(radians));
            direction.setY((float) Math.sin(radians));
        }
        if (InputManager.isTriggered(KeyEvent.VK_SPACE)) {
            if (timer >= coolDown)
            {
                SoundManager.playSoundEffect("PewPew");
                Bullet bullet = new Bullet();
                ObjectManager.addGameObject(bullet);
                bullet.setPosition(getPosition());
                bullet.fire(direction);

            }



        }
        checkWrap();
        timer += dt;
    }

    /*Creates a check wrap so you don't lose the ship off screen*/
    public void checkWrap()
    {
        float halfScreenWidth = edu.digipen.graphics.Graphics.getWindowWidth()/ 2.0f;
        float halfScreenHeight = edu.digipen.graphics.Graphics.getWindowHeight() / 2.0f;
        float offset = 32;


        /* Right */
        if(getPositionX() - offset > halfScreenWidth)
        {
            setPositionX(-halfScreenWidth - offset);
        }
        /*Left*/
        if(getPositionX() + offset < -halfScreenWidth)
        {
            setPositionX(halfScreenWidth + offset);
        }
        /*Bottom*/
        if(getPositionY() - offset > halfScreenHeight)
        {
            setPositionY(-halfScreenHeight - offset);
        }
        /*Top*/
        if(getPositionY() + offset < -halfScreenHeight)
        {
            setPositionY(halfScreenHeight + offset);
        }


    }

    @Override public void collisionReaction(GameObject other)
    {
        if(other.getName() == "asteroid")
        {
            --level.lives;
            System.out.print(level.lives);
            if(level.lives<=0)
            {
                GameLevelManager.goToLevel(new GameOverLevel(level.score));
            }
            else
            {
                SoundManager.stopBackgroundSound("BGMusic");




                setPosition(0, 0);
                setVelocity(0, 0);
                clearForces();
                setRotation(0);
                direction.set(1,0);
                level.updateLives();

            }



        }
    }




}

