import edu.digipen.gameobject.GameObject;
import edu.digipen.math.Vec2;

/**
 * Created by Anshul Karanam on 7/17/2017.
 * Class for the player projectiles
 */
public class Bullet extends GameObject

/*Size of the bullet, speed, and velocity*/
    {
        float speed = 900;
    public Bullet()
    {
        super("bullet", 32, 32   , "CircleSmall.png");
        setCircleCollider(20);
    }
    public void fire(Vec2 direction)
    {
        setVelocity(Vec2.scale(direction, speed));
    }




    }
